package Browser;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class browser {
	static By Search=By.name("q");
	public static WebDriver driver;
	

	public static WebDriver setDriver()
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		
		return driver;
		
	}
	public static void getURL(String url)
	{
		String searchData =url;
		try {
			driver.get(searchData);
		}
		catch(Exception e)
		{
			System.out.println("Inside URL Method");
		}
	}
	public static String getTitle() throws Exception
	{
		String actualTitle = driver.getTitle();
		return actualTitle;
	}
	//find Element method
	//Send Key method
	public static void sendKey(String data)
	{
		try {
		}catch(Exception e)
		{
			System.out.println("Send Key");
		}
	}
	// Driver Close Method
	public static void closeBrowser() {
		try {
			driver.close();
		}catch(Exception e)
		{
			System.out.println("closing");
		}
	}
}
