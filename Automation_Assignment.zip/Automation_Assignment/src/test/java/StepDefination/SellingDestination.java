package StepDefination;

import Browser.browser;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.BestSellingDestination;
import pageObjects.LogIn;
import pageObjects.Trainticket;


public class SellingDestination {
	BestSellingDestination objoffer;
	@Given("user lands on home page of Make My trip portal {string}")
	public void user_lands_on_home_page_of_Make_My_trip_portal(String string) {
		browser.setDriver();
		browser.getURL(string);
	}

	@When("user navigates on Holiday Packages menu and clicked on it")
	public void user_navigates_on_Holiday_Packages_menu_and_clicked_on_it() throws InterruptedException {
		objoffer = new BestSellingDestination(browser.driver);
		
		objoffer.HolidayPackage_option_button();
	}

	@And("user Scroll at Best Selling Destinations section")
	public void user_Scroll_at_Best_Selling_Destinations_section() throws InterruptedException  {
		objoffer.PageScroll();
	}

	@And("display available destinations")
	public void display_available_destinations() throws InterruptedException {
		objoffer.DisplayPlace_button();
	}

	@Then("user should get the text values of all destinations and display it")
	public void user_should_get_the_text_values_of_all_destinations_and_display_it() {
		objoffer.placePrint();
	}


}
