package pageObjects;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Browser.browser;

public class BestSellingDestination extends browser {
	static WebDriver driver;
	public BestSellingDestination(WebDriver driver) {
		this.driver = driver;
		// Call initElements() method by using PageFactory reference and pass driver and this as parameters. 
	    PageFactory.initElements( driver, this); 
	}
	
	@FindBy(xpath="//*[@class='desktop in webp']")
	public static WebElement pop_up_body_option;
	
	@FindBy(xpath="//*[contains(@class,'removeItemMargin menu_Holidays')]")
	public static WebElement HolidayPackage_option;
	
	@FindBy(xpath="//h2[contains(text(),'Best Selling Destinations!')]/../../following-sibling::div//button[text()='Next']")
	public static WebElement Display_option;
	
	@FindBy(xpath = "//h2[contains(text(),'Best Selling Destinations!')]/../../following-sibling::div/div[@class='landingCardSlider']//div[@class='itemCard__ftr']/p[1]")
	public static List<WebElement> placeName;
	
	
	
	public static void HolidayPackage_option_button()
	{
		try
		{
			pop_up_body_option.click();
			HolidayPackage_option.click();
			
		}
		catch(Exception e)
		{
			System.out.println("not found Holiday package option button");
		
		}
	}
	public static void PageScroll() throws InterruptedException
	{
		/*
		  Actions at = new Actions(driver);
		 
	      at.sendKeys(Keys.PAGE_DOWN).build().perform();
	      //identify element on scroll down
	      WebElement l = driver.findElement(By.xpath("//*[@id='root']/div/div[2]/div/main/div[5]/div[1]/div/h2"));
	      String strn = l.getText();
	      System.out.println("Text obtained by scrolling down is :"+strn);
        */
		   // identify element
		//*[@id="root"]/div/div[2]/div/main/div[5]
		//WebElement n=driver.findElement(By.xpath("//*[@id='root']/div/div[2]/div/main/div[5]"));
		
		////*[@id='root']/div/div[2]/div/main/div[6]/div[1]/div/h2
		//h2[contains(text(),'Best Selling Destinations!')]
		Thread.sleep(5000);
		/*
		 * JavascriptExecutor js = (JavascriptExecutor) driver;
		 * js.executeScript("window.scrollBy(0,250)", "");
		 * js.executeScript("window.scrollBy(250,500)", "");
		 * js.executeScript("window.scrollBy(500,750)", "");
		 */
		
		WebDriverWait wait = new WebDriverWait(driver,30);
		WebElement n = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[contains(text(),'Best Selling Destinations!')]")));
		//driver.findElement(By.xpath("//h2[contains(text(),'Best Selling Destinations!')]"));
	      // Javascript executor
	      ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", n);
	      
	      //Thread.sleep(1000);
	      
	      
	      /*
		WebElement ele = driver.findElement(By.xpath("//*[@id='root']/div/div[2]/div/main/div[5]/div[2]/div[2]/div/div/div"));

		//Creating object of an Actions class
		Actions action = new Actions(driver);

		//Performing the mouse hover action on the target element.
		action.moveToElement(ele).perform();
		*/
	}
	
	public static void DisplayPlace_button() 
	{
		/*
		Actions actions = new Actions(driver);
		WebElement elementLocator = driver.findElement(By.xpath("//body/div[@id='root']/div[1]/div[2]/div[1]/main[1]/div[5]/div[2]/div[2]/div[1]/button[2]"));
		actions.doubleClick(elementLocator).perform();
		*/
		//System.out.println("show something");
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", Display_option);
		
		for(;;)
		{
			Display_option.click();
			if(!Display_option.isEnabled())
			{
				break;
			}
		}
		
	}
	
	public static void placePrint()
	{
		for(int i=0;i<placeName.size();i++)
		{
			System.out.println(placeName.get(i).getText());
		}
	}
	
}
