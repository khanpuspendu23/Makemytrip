package StepDefination;




import Browser.browser;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.Trainticket;

public class SearchTrainTicket {
	Trainticket objtrainticket;
	@Given("user is on home page of Make My trip portal {string}")
	public void user_is_on_home_page_of_Make_My_trip_portal(String string) {
		browser.setDriver();
		browser.getURL(string);
	}

	@When("user navigates on Trains menu")
	public void user_navigates_on_Trains_menu() {
		objtrainticket = new Trainticket(browser.driver);
		objtrainticket.Train_option_button();
	}

	@And("user selects Book Trains Tickets option")
	public void user_selects_Book_Trains_Tickets_option() {
		objtrainticket.Book_trainticket_button();
	}
	@Then("User selects location in {string} section")
	public void user_selects_location_in_section(String string) throws Exception {
		objtrainticket.enterDepartureCity();
	   
	}

	@And("User select location in {string} section")
	public void user_select_location_in_section(String string) throws Exception {
		objtrainticket.enterReturnCity();
	}
	@Then("user select Date")
	public void user_select_Date() {
		objtrainticket.Date_pick();
	}

	@And("user select class")
	public void user_select_class() {
		objtrainticket.Class_pick();
	}
	@Then("user select search option")
	public void user_select_search_option() {
		objtrainticket.Search_option();
	}

}
