package StepDefination;

import org.testng.Assert;

import Browser.browser;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class browseropen {
	@Given("open the browser")
	public void open_the_browser() {
		browser.setDriver();
	}

	@When("enter the {string}")
	public void enter_the(String string) {
		browser.getURL(string);
	}

	@Then("Page is displayed")
	public void page_is_displayed() {
		try
		{
		Assert.assertEquals(browser.getTitle(),"MakeMyTrip - #1 Travel Website 50% OFF on Hotels, Flights & Holiday");
		}
		catch(Exception e)
		{
		System.out.println("Title not found");
		}
		//browser.closeBrowser();
	}


}
