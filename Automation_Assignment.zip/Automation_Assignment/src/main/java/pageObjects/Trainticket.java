package pageObjects;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class Trainticket {
	static WebDriver driver;
	public Trainticket(WebDriver driver) {
		this.driver = driver;
		// Call initElements() method by using PageFactory reference and pass driver and this as parameters. 
	    PageFactory.initElements( driver, this); 
	}
	
	@FindBy(xpath="//*[@class='desktop in webp']")
	public static WebElement popup_body_option;
	
	@FindBy(xpath="//*[contains(@class,'menu_Trains')]")
	public static WebElement Train_option;
	
    @FindBy(xpath="//*[@id='root']/div/div[2]/div/div/div/div[1]/span[1]")
	public static WebElement Book_Trainticket;
	
	@FindBy(xpath="//input[@id='fromCity']")
	public static WebElement fromCityDrop;

	@FindBy(xpath="//div[contains(@class,'react-autosuggest__section-container react-autosuggest__section-container--first')]//ul//li")
    public static List<WebElement> cityList;

	@FindBy(xpath="//input[@placeholder='From']")
	public static WebElement searchFromCity;
	
	@FindBy(xpath="//input[@placeholder='To']")
	public static WebElement searchToCity;
	
	@FindBy(xpath="//*[@id=\"root\"]/div/div[2]/div/div/div/div[2]/div/div[3]/div[1]/div/div/div/div[2]/div/div[2]/div[1]/div[3]/div[4]/div[3]")
	public static WebElement Date;
	
	@FindBy(xpath="//*[@id=\"root\"]/div/div[2]/div/div/div/div[2]/div[1]/div[4]/ul/li[3]")
	public static WebElement Class;
	
	@FindBy(xpath="//*[@id=\"root\"]/div/div[2]/div/div/div/div[2]/p/a")
	public static WebElement Search;
	
	public static void Train_option_button()
	{
		try
		{
			popup_body_option.click();
			Train_option.click();
			//Thread.sleep(2000);
		}
		catch(Exception e)
		{
			System.out.println("not found train option button");
		
		}
	}
	public static void Book_trainticket_button()
	{
		try
		{
			Book_Trainticket.click();
			//Thread.sleep(2000);
		}
		catch(Exception e)
		{
			System.out.println("not found book train ticket option");
			
		}
	}
	 //From City
    public void enterDepartureCity() throws Exception {
        fromCityDrop.click();
        //Thread.sleep(2000);
        searchFromCity.sendKeys("Mumbai");
        WebDriverWait wait = new WebDriverWait(driver,30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='From']")));
        for(int i=0;i<cityList.size();i++)
        {
            if(cityList.get(i).getText().contains("Mumbai"))
            {
                cityList.get(i).click();
              
                //Thread.sleep(2000);
                
            }
        }
        
    }
    //To City
    public void enterReturnCity() throws Exception {
        searchToCity.sendKeys("Chennai");
        WebDriverWait wait = new WebDriverWait(driver,30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='To']")));
        for(int i=0;i<cityList.size();i++)
        {
            if(cityList.get(i).getText().contains("Chennai"))
            {
                cityList.get(i).click();
          
                //Thread.sleep(2000);
                
            }
        }
    }
	
	public static void Date_pick()
	{
		try
		{
			Date.click();
			//Thread.sleep(2000);
		}
		catch(Exception e)
		{
			System.out.println("not found Date");
			
		}
	}
	public static void Class_pick()
	{
		try
		{
			Class.click();
			//Thread.sleep(2000);
		}
		catch(Exception e)
		{
			System.out.println("not found Class");
			
		}
	}
	public static void Search_option()
	{
		try
		{
			Search.click();
			//Thread.sleep(2000);
		}
		catch(Exception e)
		{
			System.out.println("not found Search option");
			
		}
	}
	

}
