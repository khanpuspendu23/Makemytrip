package StepDefination;

import static org.testng.Assert.assertTrue;

import Browser.browser;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.LogIn;
import pageObjects.Trainticket;

public class SignIn {
	LogIn objlogin;
	@Given("user is on home page {string}")
	public void user_is_on_home_page(String string) {
		browser.setDriver();
		browser.getURL(string);
	}

	@When("user clicks on Login or Create Account button")
	public void user_clicks_on_Login_or_Create_Account_button() throws InterruptedException {
		objlogin = new LogIn(browser.driver);
		objlogin.Login_button();
	}

	@And("user selects MYBIZ ACCOUNT tab")
	public void user_selects_MYBIZ_ACCOUNT_tab() {
		objlogin.Mybiz_button();
	}

	@And("User enter {string}")
	public void user_enter(String string) {
		objlogin.Emailid_button(string);
	}

	@Then("verified enable option")
	public void verify_CONTINUE_button_is_enabled_or_not() {
		boolean Expected=true;
		boolean Actual= objlogin.Continue_button(); 
		  assertTrue(Actual);
		//here i need assert method
	}


}
