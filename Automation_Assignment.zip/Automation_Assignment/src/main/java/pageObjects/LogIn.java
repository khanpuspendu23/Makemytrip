package pageObjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LogIn {
	static WebDriver driver;
	 
	
	public LogIn(WebDriver driver) {
		this.driver = driver;
		
		// Call initElements() method by using PageFactory reference and pass driver and this as parameters. 
	    PageFactory.initElements( driver, this); 
	}
	
	//*[@class='desktop in webp']
	@FindBy(xpath="//*[@class='desktop in webp']")
	public static WebElement popupbody_option;
	
	@FindBy(xpath="//*[@id=\"SW\"]/div[1]/div[1]/ul/li[4]")
	public static WebElement LogIn_option;
	
	//@FindBy(xpath="//*[@class='active']")
	@FindBy(xpath="//*[@data-acctype='myBiz']")
	public static WebElement MyBiz_option;
	
	//@FindBy(xpath="//*[@name='username']")
	@FindBy(xpath="//input[@placeholder='Enter your work email id']")
	public static WebElement EmailId_option;
	
	@FindBy(xpath="//*[@class='createMbAccount__btn flexOne appendLeft7 ']")
	public static WebElement Continue_option;
	
	public static void Login_button() throws InterruptedException
	{
		popupbody_option.click();
		Thread.sleep(1000);
			LogIn_option.click();
			
			
			//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		
	}
	public static void Mybiz_button()
	{
		try
		{
			MyBiz_option.click();
			//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			//Thread.sleep(2000);
		}
		catch(Exception e)
		{
			System.out.println("not found MyBiz button");
		
		}
	}
	public static void Emailid_button(String string)
	{
		try
		{
			EmailId_option.sendKeys(string);
			//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			//Thread.sleep(2000);
		}
		catch(Exception e)
		{
			System.out.println("not found Emailid button");
		
		}
	}
	
	public boolean Continue_button()
	{
		//try
		//{
			
			boolean continueoption=Continue_option.isEnabled();
			//Continue_option.isEnabled();
			if(continueoption==true) {
				//Continue_option.click();
				System.out.println("Continue button is enable: "+continueoption);
			}
			else
				System.out.println("continue button is not enable: "+continueoption);
			//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			//Thread.sleep(2000);
			//Continue_option.click();
			//System.out.println("Continue button is enable: "+continueoption);
		//}
		//catch(Exception e)
		/*{
			System.out.println("Continue button is not enable");
		
		}*/
		return continueoption;
	}
	
}
